let val;
let num = 10;
val = num;
console.log(val);
console.log(typeof val);
